//mongodb+srv://sehaj:Sehajpreet@1@comp3123-fullstack.cb1lg.mongodb.net/myFirstDatabase?retryWrites=true&w=majority

let express=require('express') //for api
let mongoose=require('mongoose') //for mongodb

const StudentModel=require('./models/Student')

let app=express()
let Student=require("./models/Student")
mongoose.connect('mongodb+srv://sehaj:sehaj1@comp3123-fullstack.cb1lg.mongodb.net/fall2021_comp3123?retryWrites=true&w=majority',
{
    useNewUrlParser:true,
    useUnifiedTopology:true
})


app.get("/",(req,res)=>{
    res.send("<h1>MongoDb mongoose Example</h1>")
})
//Insert New Student
app.get("/add",async (req,res)=>{
 //We do async and await beacsue we want to wait until the student is saved or else the message will be sent ffirst
 //before saving and stduent will not be saved and both messages that is error and success will be sent together
 //so we wait and then save and then sent the message
let s={
    first_name:"Sehaj",
    last_name:"Kaur",
    total:200
}
let new_student=new StudentModel(s)
try{
    await new_student.save(s)
    console.log("Student Record Saved")
    res.status(200).send("Student Record Saved")
}
catch(err){
    console.log("Error Record Not Saves"+err)
res.status(500).send(err)
}

    res.send("<h1>MongoDb mongoose Example</h1>")
})
//read student data

app.get("/students",async(req,res)=>{
   // const s= await StudentModel.find({})
    //const s= await StudentModel.find({},"first_name")
    //const s= await StudentModel.find({},"first_name total")
   // const s= await StudentModel.find({total:100})
   //sort in ascending = 1 , descending=-1
   //const s= await StudentModel.find({},"first_name total").sort({total:1})
   //greater than 100
   const s= await StudentModel.find({total:{$gt:100}},"first_name total")
     // directly on Modela as its find but for create we do on object
    try{
        res.send(s)
    }
    catch(err){
console.log('Error',err)
res.status(500).send(err)
    }
})
app.listen(3001,()=>{
    console.log("Server starting at http://localhost:8081/")
})